const victimsArray = [
  {
    pictureUrl: 'images/victims/heart.png',
    quantity: 0,
  },
  {
    pictureUrl: 'images/victims/liver.png',
    quantity: 0,
  },
  {
    pictureUrl: 'images/victims/eyes.jpg',
    quantity: 4,
  },
  {
    pictureUrl: 'images/victims/kidney.jpg',
    quantity: 0,
  },
  {
    pictureUrl: 'images/victims/hairs.jpg',
    quantity: 5,
  },
  {
    pictureUrl: 'images/victims/teeth.png',
    quantity: 12,
  },
  {
    pictureUrl: 'images/victims/stomash.jpg',
    quantity: 0,
  },
  {
    pictureUrl: 'images/victims/testies.png',
    quantity: 1,
  },
  {
    pictureUrl: 'images/victims/lungs.jpg',
    quantity: 2,
  },
  {
    pictureUrl: 'images/victims/brain.png',
    quantity: 0,
  },
];
