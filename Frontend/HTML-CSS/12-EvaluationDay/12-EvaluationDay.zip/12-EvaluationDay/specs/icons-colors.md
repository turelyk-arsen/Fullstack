# Folors

grey background : #F6F8F9
red/pink button + tick : #FA6980
dark grey footer : #A6ADB4
text white : #FFFFFF
black-text : #202124
grey-text : #A6ADB4

# Fonts

Main heading font is : Limelight
Everywhere else : Roboto

# Icons from Font Awesome

- bars
- instagram
- facebook-f
- twitter
- globe-europe
